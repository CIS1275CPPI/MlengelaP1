/*  HelloWorld.cpp : This file contains the 'main' function.
    Programmer: Daudi Mlengela (dmlengela@cnm.edu
    Date: 1 September 2021
    Purpose: Demostrate how to create a program */

#include <iostream>

using namespace std; 

int main()
{
    cout << "Hello World!\n";

    return 0;
}


