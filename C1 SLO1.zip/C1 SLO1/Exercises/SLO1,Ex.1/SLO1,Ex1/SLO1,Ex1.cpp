/* Programmer: Daudi Mlengela (dmlengela@cnm.edu)
* Date: 2 september 2021
* Purpose: Printing a Welcome Text in a separate line */

#include <iostream>

using namespace std;
int main()
{
	cout << " Print a Welcome text in a separate line : \n";
	cout << "...................................... \n";
	cout << " Welcome to \n";
	cout << " C++ Programming I" << endl;

	return 0;
}
