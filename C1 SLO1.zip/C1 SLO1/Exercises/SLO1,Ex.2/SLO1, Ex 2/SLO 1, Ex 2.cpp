/* Programmer: Daudi Mlengela (dmlengela@cnm.edu)
Date: 5 september 2021
Purpose: To Demostrate both kind of Comments 
and the output should be my name and concentration */

#include <iostream>

using namespace std;

int main()
{
	/* cout << "Hello World!  \n";
	    and We don't need Hello World anymore! */ // multiple comment

	cout << "\n My name is Daudi and my concentration is Web Programming. ";


	return 0; 
}