/*Day1Demos.ccp
 Programmer: Daudi Mlengela (dmlengela@cnm.edu)
 Date: 1 september 2021
 Purpose: Experiement with Code */

#include <iostream>

using namespace std;

int main()
{



	return 0;
}
