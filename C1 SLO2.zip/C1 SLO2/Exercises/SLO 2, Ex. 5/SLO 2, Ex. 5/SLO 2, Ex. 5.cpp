/*Programmer: Daudi Mlengela (dmlengela@cnm.edu)
Date: 2 September 2021
Purpose: Declaration and initialization of two Const numbers using uniform initialization. 
Using them to calculate the area and count the calculation. 
The area of a circle is pi * radius * radius */

#include <iostream>
using namespace std;

const double PI{ 3.14159 };
const char NEWLINE{ '\n'  };

int main()

{
	double radius{ 5.0 };
	double areaCircle{ 0.0 };

	areaCircle = PI * radius * radius;

	cout << NEWLINE << " The area of a circle with a radius of " << radius << " is " << areaCircle << NEWLINE;

	return 0; 
}