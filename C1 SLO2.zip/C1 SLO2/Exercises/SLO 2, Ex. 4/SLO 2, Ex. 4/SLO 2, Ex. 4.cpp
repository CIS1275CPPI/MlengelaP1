/* Programmer: Daudi Mlengela (dmlengela@cnm.edu)
Date: 2 September 2021
Purpose: To Print the sun of two numbers using variables. Declare and initialize two numbers using uniform 
initialization. */

# include <iostream>

using namespace std;

int main()
{
	int students{ 19 };
	int visitors{ 4 };

	int sum = students + visitors;
	cout << "\n The sum of " << students << " and " << visitors << " is " << sum << endl;

	return 0;

}